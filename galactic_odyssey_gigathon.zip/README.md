
# Galactic Odyssey 🚀

Proyecto avanzado para Gigathon 2026.

## Características extra para ganar más puntos

✅ Mundo bidimensional grande  
✅ Turtle avanzada con mapa y puntos especiales  
✅ Sistema de energía  
✅ Sistema de oxígeno  
✅ Integridad del casco  
✅ Inventario  
✅ Puntuación final  
✅ Eventos aleatorios  
✅ Objetos especiales  
✅ Terrenos diferentes  
✅ Portales alienígenas  
✅ Bases abandonadas  
✅ Piratas espaciales  
✅ Informe final detallado  
✅ Rejugabilidad infinita  
✅ Ambientación creativa de ciencia ficción  

## Cómo ejecutar

```bash
python main.py
```

Compatible con Python 3.11 y únicamente usa librerías estándar.
